import streamlit as st
from keras.models import load_model
from keras.preprocessing import image
import numpy as np

# Load the trained model
model = load_model('./bestmodel.h5')  # Provide the correct path

# Function to preprocess the image
def preprocess_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.0  # Normalize
    return img_array

# Streamlit App
st.title("Brain Tumor Classification")

# Upload an image through Streamlit
uploaded_file = st.file_uploader("Choose a brain MRI image...", type=["jpg", "jpeg", "png"])

# Display the uploaded image
if uploaded_file is not None:
    st.image(uploaded_file, caption="Uploaded Image", use_column_width=True)

    # Make prediction when the "Predict" button is clicked
    if st.button("Predict"):
        st.spinner("Predicting...")

        # Save the uploaded image
        img_path = "temp_image.jpg"
        with open(img_path, "wb") as f:
            f.write(uploaded_file.getbuffer())

        # Preprocess the image
        img_array = preprocess_image(img_path)

        # Make prediction
        prediction = model.predict(img_array)
        result = 'Tumor' if prediction[0, 0] > 0.5 else 'No Tumor'

        st.success(f"Prediction: {result}")
